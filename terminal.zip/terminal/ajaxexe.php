<?php
ob_start();

include('./appdbconfig.php');

include('./svrconn.php');

include("./phpmagicbits.php");

function help()
{
return "Type echo fend_help(); for front end and echo bend_help(); for back end";
}

include("./phpmagicui.php");
include("./phpmagicbackend.php");

  //error handler function

  function customError($errno, $errstr) {
    echo "<b>Error:</b> [$errno] $errstr<hr>".help();
  }

  //set error handler
  //set_error_handler("customError");

if(isset($_POST['execute_terminal']))
{

		  $file_to_write = fopen($_POST['txt_directory'], 'w') or die("can't open file");
		  fwrite($file_to_write, "<?php ".$_POST['txt_new_code']."?>");
		  fclose($file_to_write);

		  echo "Input : ".$_POST['txt_new_code'].'<hr style="border : 1px solid #7f7e7e">Output : ';

		  include(($_POST['txt_directory']));

}


if(isset($_POST['load_file']))
{
	echo file_get_contents($_POST['txt_writeto']);

}

if(isset($_POST['load_notes']))
{
	if (!file_exists($_POST['txt_writeto'])) {
		  $file_to_write = fopen($_POST['txt_writeto'], 'w') or die("can't open file");
		  fwrite($file_to_write, '');
		  fclose($file_to_write);
	}

	echo file_get_contents($_POST['txt_writeto']);

}

if(isset($_POST['save_file']))
{

	$backup= file_get_contents($_POST['txt_writeto']);

   if (!file_exists('./edithistory')) @mkdir('./edithistory');

		  $file_to_write = fopen('./edithistory/'.magic_basename($_POST['txt_writeto'])."_".date("dmyhisa").'_bkup.astg', 'w') or die("can't open file");
		  fwrite($file_to_write, $backup);
		  fclose($file_to_write);

	 file_put_contents($_POST['txt_writeto'], $_POST['txt_new_code']);

	 echo "File Saved";
}

if(isset($_POST['save_file_preview']))
{
$inject_scroll_set ='<style type="text/css">/* width */::-webkit-scrollbar {width: 4px;box-shadow: 2px 2px 3px 3px lightgray;}/* Track */::-webkit-scrollbar-track {background: #FFF; }/* Handle */::-webkit-scrollbar-thumb {background: green; border-radius: 90px;}/* Handle on hover */::-webkit-scrollbar-thumb:hover {background: #000; }</style>';

		  $file_to_write = fopen($_POST['txt_writeto']."/load_preview_iframe_23_01_21_438pm.php", 'w') or die("can't open file");
		  fwrite($file_to_write,$_POST['txt_new_code'].$inject_scroll_set);
		  fclose($file_to_write);

	 echo "File Preview Saved";
}


if(isset($_POST["asn_snippets_insert_btn"])){
//------- begin Create Update record from asn_snippets --> 
$snippetid=mysqli_real_escape_string($mysqliconn, magic_random_str(10));
$snippet_title=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_title"]);
$snippet_details=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_details"]);
//===-- End Create Update record from asn_snippets -->


$asn_snippets_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$asntag`.`asn_snippets` (`primkey`,`snippetid`,`snippet_title`,`snippet_details`) VALUES (NULL,'$snippetid','$snippet_title','$snippet_details')");

echo "Snippet Added";
}
//************* END INSERT QUERY 

if(isset($_POST["update_snippet"])){
//------- begin Create Update record from asn_snippets --> 

$snippet_title=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_title"]);
$snippet_details=mysqli_real_escape_string($mysqliconn, $_POST["txt_snippet_details"]);
$snippet_key=mysqli_real_escape_string($mysqliconn, $_POST["snippet_key"]);
//===-- End Create Update record from asn_snippets -->


$asn_snippets_insert_query = mysqli_query($mysqliconn, "UPDATE `$asntag`.`asn_snippets` SET `snippet_title`='$snippet_title',`snippet_details`='$snippet_details' WHERE primkey='$snippet_key'");



echo "Snippet Updated";
}
//****

if(isset($_POST["delete_snippet"])){
//------- begin Create Update record from asn_snippets --> 

$snippet_key=mysqli_real_escape_string($mysqliconn, $_POST["snippet_key"]);
//===-- End Create Update record from asn_snippets -->

$asn_snippets_insert_query = mysqli_query($mysqliconn, "DELETE FROM `$asntag`.`asn_snippets`  WHERE primkey='$snippet_key'");



echo "Snippet Deleted";
}
//****




if(isset($_POST["qasn_snippets_btn"])){

$qasn_snippets=mysqli_real_escape_string($mysqliconn, ($_POST["qasn_snippets"]));

//=== start asn_snippets select  Like Query String asn_snippets list  

$asn_snippets_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" );
$snippent_r="";

while($asn_snippets_list_r=mysqli_fetch_array($asn_snippets_list_query))
{
	$snippent_r.='Snippet -- <b id="snippet_title_'.$asn_snippets_list_r['primkey'].'">'.$asn_snippets_list_r['snippet_title'].'</b> | <span style="display:inline-block; cursor:pointer;" onclick="edit_snippet(\''.$asn_snippets_list_r['primkey'].'\')"><u>Edit</u></span><br><textarea class="snippet_card" id="snippet_desc_'.$asn_snippets_list_r['primkey'].'" onclick="load_to_editor(this.value);  document.getElementById(\'msg_alert_myModal\').style.display=\'none\'" onkeydown = "if (event.keyCode == 13) {event.preventDefault();  load_to_editor(this.value);   document.getElementById(\'msg_alert_myModal\').style.display=\'none\';}">'.$asn_snippets_list_r['snippet_details'].'</textarea>';
}

echo '`'.$qasn_snippets.'` Results <br><br>'.$snippent_r ;

//=== End asn_snippets select  Like Query String asn_snippets list


}

if(isset($_POST["flag_search"])){

$qasn_snippets=mysqli_real_escape_string($mysqliconn, ($_POST["qasn_snippets"]));

//=== start asn_snippets select  Like Query String asn_snippets list  
$fkey_q=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" );

$fkey_r=mysqli_fetch_array($fkey_q);

$fkey=$fkey_r['primkey'];

$asn_snippets_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" );

$snippent_f='<Input type="hidden" id="flag_focus" value="'.$fkey.'_flash_text_node"/>';


while($asn_snippets_list_r=mysqli_fetch_array($asn_snippets_list_query))
{
	$snippent_f.='<b style="color:#bfccbf;">'.$asn_snippets_list_r['snippet_title'].'</b><br><textarea class="snippet_card flag_focus" onclick="load_to_editor(this.value); document.getElementById(\'flag_search_div\').style.display=\'none\'" onkeydown = "if (event.keyCode == 13){ event.preventDefault(); load_to_editor(this.value); document.getElementById(\'flag_search_div\').style.display=\'none\';}" id="'.$fkey.'_flash_text_node" style="width: 100%; height: 40px; margin-top: 8px;" readonly >'.$asn_snippets_list_r['snippet_details'].'</textarea>';
}

if($fkey!=''){
echo $snippent_f;

}

//=== End asn_snippets select  Like Query String asn_snippets list


}

if(isset($_POST["flag_console_search"])){

$qasn_snippets=mysqli_real_escape_string($mysqliconn, ($_POST["qasn_snippets"]));

//=== start asn_snippets select  Like Query String asn_snippets list  

$asn_snippets_list_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`asn_snippets`  WHERE (`snippet_title` LIKE '%".$qasn_snippets."%' OR  `snippet_details` LIKE '%".$qasn_snippets."%') ORDER BY `primkey` DESC LIMIT $datalimit" );
$snippent_f="";

while($asn_snippets_list_r=mysqli_fetch_array($asn_snippets_list_query))
{
	$snippent_f.='<b style="color:#bfccbf;">'.$asn_snippets_list_r['snippet_title'].'</b><br><textarea class="snippet_card" onclick="load_to_console(this.value);  document.getElementById(\'flag_search_div\').style.display=\'none\'" onkeydown = "if (event.keyCode == 13){ event.preventDefault(); load_to_console(this.value); document.getElementById(\'flag_search_div\').style.display=\'none\';}" style="width: 100%; height: 40px; margin-top: 8px;" readonly >'.$asn_snippets_list_r['snippet_details'].'</textarea>';
}

echo $snippent_f;

//=== End asn_snippets select  Like Query String asn_snippets list


}



if(isset($_POST['loop_folder']))
{

$parent=$_POST['folder'];

 if (!file_exists($parent)){
 	echo "DNF";
 }else{


if ($handle = opendir($parent)) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
		$a = $entry;
	
		if (strpos($a, '.') !== false) {
		$dirtype="File";
		$fileicon="file";
			$folderrec= '<a href="'.$parent.'/'.$entry.'" target="_blank" title="View File">VF</a>  | <div style="color:#FFF; cursor:pointer; text-decoration:underline; display:inline-block" onclick="load_to_editor(\''.$parent.'/'.$entry.'\')" title="Add to editor">ATE</div> | <a href="#"  onclick="load_to_path(\''.$parent.'/'.$entry.'\')" title="Load to Path">LTP</a> | <a href="#"  onclick="document.getElementById(\'setcursor\').value=\'block_set_cursor\';load_to_path(\''.$parent.'/'.$entry.'\');load_file()" title="View Source Code">VSC</a> | <a href="#"  onclick="add_to_frame(\''.$parent.'/'.$entry.'\');" title="Add to Frame">ATF</a>';
		}else{
				$dirtype="Folder";
				$fileicon="fld";

		    $folderrec= '<a href="#"  onclick="document.getElementById(\'folderpath\').value=\''.$parent.'/'.$entry.'\';loop_open_folder(\''.$parent.'/'.$entry.'\')">Open Folder</a>' ;

		}

echo '
<div class="function_card" style="border-bottom:1px solid #CCC; margin-bottom:9px;">
<div style="display:inline-block; padding:3px;">
<img src="'.$fileicon.'.png" style="width:20px;"/>
 '.$entry.'
</div>
<div style=" font-size:12px; margin:7px;">
<div class="cpointer">'.$folderrec.'</div>
</div>
</div>';

		 }
    }

    closedir($handle);
}

}
}


function strip_selected_tags_by_id_or_class($array_of_id_or_class, $text,$replacewith)
{
   $name = implode('|', $array_of_id_or_class);
   $regex = '#<(\w+)\s[^>]*(class|id)\s*=\s*[\'"](' . $name .
            ')[\'"][^>]*>.*</\\1>#isU';
    //echo "curr regexed ".$regex;
   return(preg_replace($regex, $replacewith, $text));
}

if(isset($_POST['update_page_file']))
{

$array_of_id_or_class=array($_POST['element_id']);
$element_id=$_POST['element_id'];
$new_element_cont1=$_POST['new_elem_cont'];

$new_element_cont2 = str_replace("<div>", '<br>', $new_element_cont1);
$new_element_cont = str_replace("</div>", '', $new_element_cont2);

$current_file="../".$_POST['file_name'];
$getbkup=$_POST['file_name'];
$tag_start=$_POST['tag_start'];
$tagname=$_POST['tagname'];
$recreated_tag =$tag_start.PHP_EOL."\t\t".($new_element_cont).PHP_EOL."\t\t</".$tagname.">";


	$backup= file_get_contents($current_file);

   if (!file_exists('./page_edithistory')) @mkdir('./page_edithistory');

		  $file_to_write = fopen('./page_edithistory/'.($getbkup)."_".date("d_m_y_h_i_s_a").'_bkup.astg', 'w') or die("can't open file");
		  fwrite($file_to_write, $backup);
		  fclose($file_to_write);

if($tagname=='img'){

$dom = new DOMDocument();
@$dom->loadHTML(file_get_contents($current_file), LIBXML_HTML_NODEFDTD);

$image = $dom->getElementById($element_id);

$image->setAttribute('src', $new_element_cont);

$dom->removeChild($dom->doctype);  

$newfile_str1=$dom->saveHTML();

$newfile_str=str_replace('<html lang="en">', '<!DOCTYPE html>'.PHP_EOL.'<html lang="en">', $newfile_str1);
}else{
$text=file_get_contents($current_file);

$newfile_str=strip_selected_tags_by_id_or_class($array_of_id_or_class, $text, $recreated_tag);



}

  $fh2 = fopen($current_file, 'w') or die("can't open file");
  fwrite($fh2, $newfile_str);
  fclose($fh2);


}

if(isset($_POST["insert_code_time"])){

//------- begin sql_comment --> 

$entry_id=mysqli_real_escape_string($mysqliconn, date('Y-m-d h:i:s A'));
$start=mysqli_real_escape_string($mysqliconn, date('Y-m-d h:i:s A'));
$end=mysqli_real_escape_string($mysqliconn, date('Y-m-d h:i:s A', strtotime($_POST['txt_end'])));
$folder=mysqli_real_escape_string($mysqliconn, $_POST["txt_folder"]);

//===-- End sql_comment -->



//=== start code_track select  query 

$_code_track_query=mysqli_query($mysqliconn, "SELECT * FROM `$asntag`.`code_track` ORDER BY `primkey` DESC LIMIT 1" );

$latest_entry=mysqli_fetch_array($_code_track_query);

//=== End code_track select   query
//--<{ncgh}/>

$code_track_uptoken=$latest_entry['primkey'];

$curr_time=strtotime(date("Y-m-d H:i:s"));
$latest_entry_time=strtotime(date("d-m-Y H:i:s", strtotime($latest_entry['end'])));

$time_diff=$curr_time-$latest_entry_time;

$start_beacon=strtotime(date("d-m-Y H:i:s", strtotime($latest_entry['start'])));
$latest_entry_time=strtotime(date("d-m-Y H:i:s", strtotime($latest_entry['end'])));

$becon_time_diff=number_format((($latest_entry_time-$start_beacon)/60), 2, ".", ".");


if($time_diff>600 || $code_track_uptoken==''){
//------- begin Insert Query  --> 
$code_track_insert_query = mysqli_query($mysqliconn, "INSERT INTO `$db`.`code_track` (`primkey`,`entry_id`,`start`,`end`,`time_diff`,`folder`) 
 VALUES 
(NULL,'$entry_id','$start','$end','$time_diff','$folder')");
}else{
$code_track_update_query = mysqli_query($mysqliconn, "UPDATE  `$db`.`code_track` SET `end`='$end',`time_diff`='$becon_time_diff',`folder`='$folder' WHERE primkey='$code_track_uptoken'");
}
//------- End insert Query  --> 

echo $time_diff." curr_time ".$curr_time." latest_entry_end ".$latest_entry['end']." curr key ".$code_track_uptoken;
}



?>