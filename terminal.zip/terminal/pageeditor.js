// To make an element editable, just add edt_ before the id, eg, <div id="edt_yourid"> {content to replace}</div>

$(document.body).click(function(evt){
  var clicked = evt.target;

  var elem_new_id = "new_node_id_";

  var currentID = clicked.id;

if(currentID!=''){
var edt_parse =currentID.split('_')[0];
if(edt_parse=='edt'){

var content_guide =document.getElementById(currentID).innerHTML;

if(content_guide==''){
content_guide='Click here to type';
}
var content_card ='<div id="to_pg_editor_card21012021" contenteditable="true">'+
''+content_guide+'</div><hr>'+
'<div onclick="update_file(\''+currentID+'\')" class="btn btn-primary">Save</div>';


magic_screen('<hr>'+content_card, 'render_pg_editor_card21012021');


document.getElementById('clicked_div').value=currentID;

}
//
}else{

clicked.id=elem_new_id;
//pop_editor(elem_new_id);

}

})

function update_file(element_id)
{

const getAllAttributes = el => el
  .getAttributeNames()
  .reduce((obj, name) => ({
    ...obj,
    [name]: el.getAttribute(name)
  }), {});


var tag_attributes = getAllAttributes(document.querySelector('#'+element_id+''));

var decoded_attr= (tag_attributes);
var tag_styles="";
for (var key in decoded_attr) {
    if (decoded_attr.hasOwnProperty(key)) {
        tag_styles+= key + "=" + '"'+decoded_attr[key]+'" '
    }
}

console.log(tag_styles);

var tagname =(document.getElementById(element_id).tagName).toLowerCase();

var recreated_elem ='<'+tagname+' '+tag_styles+'>';

var file_name1 =get_basefile(window.location.href);

var new_elem_cont= document.getElementById('to_pg_editor_card21012021').innerHTML;

if(file_name1.includes('.php')){
	var file_name=file_name1;
}else{

var file_name=file_name1+".php";

}

	 $.ajax({ 
      url: './terminal/ajaxexe.php',
      type: "POST",
      data: {
        'update_page_file':'ok',
        'tag_start':recreated_elem,
        'element_id':element_id,
        'file_name':file_name,
        'new_elem_cont':new_elem_cont,
        'tagname':tagname
      },

      success: function (data) {

     //alert(data);
    window.location=window.location.href;
        //document.getElementById(element_id).scrollIntoView();
      }

  })
}

function get_basefile (url) 
{ return url?url.split('/').pop().split('#').shift().split('?').shift():null }

document.body.innerHTML += '<style type="text/css">[id^="edt_"]{color: red;font-weight: bold!important; cursor:pointer}</style><div id="render_pg_editor_card21012021"></div>';