$f1=file_get_contents('../f1.txt');

$f2=explode("\n", $f1);

foreach ($f2 as $key => $value) 
{


if($value!='')
{
//echo $key." F ". $value;

//here
}
}