<link rel="stylesheet" href="boot.css"/>
<div class="text-white row col-md-12 bg-primary p-3 m-0 p-0 justify-content-end ">
Top Set
</div>
<nav class="navbar navbar-expand-md navbar-light shadow-sm  border-bottom border-light  bg-white">
    <a class="navbar-brand text-dark" href="#">
        <img src="../img/logo.png" style="width: 50px; height: 50px; border-radius: 50%;" /> Demo Site
        <div class="ml-3" style="font-size:11px; padding-left: 50px; font-weight: bold; border-top: 0px solid #FFF; margin-top: -6px;">Site Slogan</div>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria controls="navbarsExampleDefault"aria-expanded="false" aria-label="Toggle navigation">
        <i class="fa fa-bars"></i>
    </button>

    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav ml-lg-5">
            <li class="nav-item ml-lg-5">
                <a class="nav-link" href="./index">Home</a>
            </li>
        </ul>
    </div>
</nav>
<div class="col-md-12 mb-4">
<a href="" class="btn btn-primary mb-3">Link Demo</a>
</div>
<div class="col-md-12 p-2 text-center border border-secondary" style="height:auto;">
<!-- Start Circle -->
<div class="mr-3" style="height:100px; width:100px; border:1px solid #000; border-radius:50%; line-height:90px; text-align:center; background-color:red;  display:inline-block;">
Stuff
</div>
<!-- End Circle -->

<!-- Start Circle -->
<div style="height:70px; width:70px; border:1px solid #000; border-radius:50%; line-height:65px; text-align:center; background-color:#f2c201;  display:inline-block;">
Stuff
</div>
<!-- End Circle -->

</div>
<!-- Start left right card  -->

<div class="row justify-content-center col-md-12 mb-3 mb-lg-0  p-lg-4 bg-white">

    <!-- Start left card -->
    <div class="col-md-5 mr-lg-2 p-0">

      <img src="../../img/bg.png" class="col-md-12 mt-2 m-0 p-0" style="width:200px" id=""/>

    </div>
    <!-- End left card -->
    <!-- Start right card -->
    <div class="col-md-6">
      <!-- Start  Title ribbon-->
      <h5 class="col-md-12 row pt-2 pb-2 justify-content-center pr-0">
        <div class="col-md-4 pl-0 mr-lg-2 text-left text_center_mobi">Internet solutions</div>
        <div class="col-md-7 bg-white mt-lg-3" style="height: 1px"></div>
      </h5>
      <!-- End Title ribbon-->
      <div class="ml-lg-3 text_center_mobi" style="">
        Awesome description of the title 
      </div>
<div class="col-md-12 pt-3 text_center_mobi">
      <a href="" class="btn btn-primary mb-3">Inquire More</a>
</div>

    </div>
    <!-- End right card -->
</div>
<!-- End left right card  -->
        <!-- bottom card -->
        <div class="col-md-3 p-0 mr-lg-2 text-center">
            <img src="../../img/bg.png" class="" style="width:90px; height:90px; border-radius:90px;" id=""/>
            <h5 class="col-md-12 text-center mt-3" style="">Card Title</h5>
            <div class="col-md-12 text-center mt-3 mb-4" style="">
                thsis an awesome paragraph
            </div>
        </div>
        <!-- bottom card -->



