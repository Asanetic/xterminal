<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

$server_db='tgai';
$dbname=$server_db;
$db=$server_db;

$datalimit=15;


//=========
$col_script="
`primkey` int(255) PRIMARY KEY AUTO_INCREMENT,
`snippetid` varchar(500) NOT NULL,
`snippet_title` varchar(500) NOT NULL,
`snippet_details` blob NOT NULL";


$snippet_code="
`primkey` int(255) PRIMARY KEY AUTO_INCREMENT,
`snippetid` varchar(500) NOT NULL,
`snippet_title` varchar(500) NOT NULL,
`snippet_details` blob NOT NULL";
//snippet table == asn_snippets


$navbar_path="./includes/navbar.php";
$footer_path="./includes/footer.php";
$header_css_scripts="./includes/header_css_scripts.php";
$background_image_path="";
$template_path="";

$icon_title_json='{"New Projects":"./img/logo.png","Revisions":"./img/logo.png","Available Projects":"./img/logo.png"}';


?>