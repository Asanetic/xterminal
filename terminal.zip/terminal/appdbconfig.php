<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

$dbname='tgai';
$db='tgai';
$server_db='tgai';

$datalimit=15;

?>