<?php

$host="localhost"; // Host name 
$username="root"; // Mysql username 
$password=""; // Mysql password

$dbname='infolinkdb';
$db='infolinkdb';
$server_db='infolinkdb';

$datalimit=15;

?>