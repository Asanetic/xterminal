<?php //====write to file 

$file_path='../inventory.php';
//$new_content_to_write='';
$new_content_to_write=file_get_contents('../client-arrears.php');


bend_write_to_file($file_path, $new_content_to_write);
?>