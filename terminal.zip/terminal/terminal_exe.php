<?php $tbl='suppliers';
$where_str='';
$param_fields=magic_sql_array_cols($tbl);
$file_path='../data_control/ajax.php';
$create_new_file='no';
$orderby_col='primkey';
$ordertype='desc';
$comment='Like Query String '.$tbl;

full_bend_select_str($db, $tbl, $where_str, $param_fields, $file_path, $create_new_file, $orderby_col, $ordertype, $comment)
?>