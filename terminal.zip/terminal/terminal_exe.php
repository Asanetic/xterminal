<?php //===create app frame

$page_title='index';
$newfile_name='../acyhouse';

create_appframe($page_title, $navbar_path, $footer_path, $header_css_scripts, $newfile_name, $background_image_path, $template_path);

?>