<?php $file_path='../ugrid_tbl.php';
$tbl='ugrid_tbl';
$fileds_n_values_json=magic_sql_json_cols($tbl); 
$create_new_file='no';
$edit_key='primkey';
$plain_link='no';
$linkcol='';
$write_here='//here';
$editable='yes';

create_ugrid($file_path, $fileds_n_values_json, $tbl, $editable, $create_new_file, $edit_key, $plain_link, $linkcol, $write_here);
?>