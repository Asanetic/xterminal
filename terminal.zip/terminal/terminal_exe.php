<?php $reset_all_yes_no="";

refresh_vars($reset_all_yes_no)?>