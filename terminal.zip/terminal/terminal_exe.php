<?php ///backup file
 backup_file('marchtbl_snippet.sql', file_get_contents('../25thmar.sql'));

?>