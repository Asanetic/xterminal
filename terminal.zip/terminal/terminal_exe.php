<?php //===create app frame
$oauth_table="";
$primkey='primkey';
$session_user_mail='email';
$username='';
$password='password';

$login_page_title='Login';
$login_file='../'.$oauth_table.'_login.php';

$register_page_title='Create Account';
$register_file='../'.$oauth_table.'_register.php';

$reset_password_page_title='Request Password Reset';
$reset_password_file='../'.$oauth_table.'_reset_password.php';

$change_password_page_title='Reset Password';
$change_password_file='../'.$oauth_table.'_change_pass.php';

if($oauth_table=='' || $primkey=='' || $username=='' || $session_user_mail =='' || $password=='')
{
echo "<h2>Easy now!! Please check if all variables are filled </h2>";
}else{
create_appframe($login_page_title, $navbar_path, $footer_path, $header_css_scripts, $login_file, $background_image_path, $template_path);
create_appframe($register_page_title, $navbar_path, $footer_path, $header_css_scripts, $register_file, $background_image_path, $template_path);
create_appframe($reset_password_page_title, $navbar_path, $footer_path, $header_css_scripts, $reset_password_file, $background_image_path, $template_path);
create_appframe($change_password_page_title, $navbar_path, $footer_path, $header_css_scripts, $change_password_file, $background_image_path, $template_path);

//==== create login reset passwrod and create acc ui

create_accounts_ui($login_file, 'login');
create_accounts_ui($register_file, "newacc");
create_accounts_ui($reset_password_file, 'resetrequest');
create_accounts_ui($change_password_file, 'updatepass');

$comment='Log in to '.$oauth_table;
$gotourl='./dashboard';
$session_name='session_'.$oauth_table."_logged";
$create_new_file='yes';
$session_oauth_file='../data_control/'.$oauth_table.'_oauth.php';

create_login($dbname, $oauth_table, $primkey, $session_user_mail, $username, $password, $comment, $gotourl, $session_name, $create_new_file, $session_oauth_file);

  
$session_monitor_file='../'.$oauth_table.'_sessionmonitor.php';

$session_monitor_filescript='
<?php
if(!isset($_SESSION["'.$session_name.'"]))
{

	$ref_url_go_to=\'?ref_url_go_to=\'.base64_encode(magic_current_url());
	
	header(\'location:./'.str_replace("../", "", $login_file).'\'.$ref_url_go_to.\'\');

	exit;

}
?>';
//====write Session Monitor file 

bend_write_to_file($session_monitor_file, $session_monitor_filescript);


///====write logout file 

$session_logout_file='../'.$oauth_table.'_sessionlogout.php';

$session_logout_filescript='
<?php
include(\'./data_control/conn.php\');

unset($_SESSION["'.$session_name.'"]);
unset($_SESSION[\''.$session_name.'_'.$session_user_mail.'\']);
unset($_SESSION[\''.$session_name.'_'.$username.'\']);

	header(\'location:./'.str_replace("../", "", $login_file).'\');
    
?>';
//====write Session Monitor file 

bend_write_to_file($session_logout_file, $session_logout_filescript);

//== write connection files
$data_includes="
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
//include('./data_control/datafeed.php');
include('".str_replace("../", "./", $session_oauth_file)."');
//include('./".$oauth_table."_sessionmonitor.php')";

//========= replace text in a file_path
$item_to_be_replaced='ob_start()';
$item_to_replace_with=$data_includes;

bend_replace_file_section($login_file, $item_to_be_replaced, $item_to_replace_with);
bend_replace_file_section($register_file, $item_to_be_replaced, $item_to_replace_with);
bend_replace_file_section($reset_password_file, $item_to_be_replaced, $item_to_replace_with);
bend_replace_file_section($change_password_file, $item_to_be_replaced, $item_to_replace_with);

}
?>