<?php $tbl='client_charges';
  echo magic_sql_json_cols($tbl)?>