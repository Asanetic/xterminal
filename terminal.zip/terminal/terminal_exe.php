<?php //create bootstrap form 
$write_to_path='../editadmin.php';
$tbl='admin';
$rows_per_grid='5';
$grid_class='col-md-7';
$elements_plate='';
$ui_comment='Sql input';
$write_here='//here';
$fileds_n_values_json=magic_sql_json_cols($tbl);
$create_new_file='no';


create_magic_form($write_to_path,  $fileds_n_values_json, $tbl, $rows_per_grid, $grid_class, $elements_plate, $ui_comment, $write_here, $create_new_file)?>