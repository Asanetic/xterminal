<?php $file_path='../inventory.php';
$tbl='inventory';
$fileds_n_values_json=magic_sql_json_cols($tbl); 
$create_new_file='no';
$edit_key='primkey';
$plain_link='no';
$linkcol='';
$write_here='//here';

create_table_ui($file_path, $fileds_n_values_json, $tbl, $create_new_file, $edit_key, $plain_link, $linkcol,$write_here);
?>