<?php //magic_sql_export_db($host,$username, $password, $db, '../terminalsnippet', "admin, client_base, transactions");

//magic_sql_import_db('../qp.sql', $host, $username, $password, 'qpost');


backup_file('terminalsnippet.sql', (file_get_contents('../terminalsnippet.sql')));
?>