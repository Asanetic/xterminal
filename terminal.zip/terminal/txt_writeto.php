//===create app frame

$tbl='app_nodes';

$newfile_profile='../edit'.$tbl.'.php';
$newfile_name='../'.$tbl.'.php';
$write_here='<!--<{ncgh}/>-->';

$page_title=ucwords((str_replace('_', " ", $tbl)));
create_appframe($page_title, $navbar_path, $footer_path, $header_css_scripts, $newfile_name, $background_image_path, $template_path);


$page_profile=ucwords((str_replace('_', " ", $tbl)));
create_appframe($page_profile, $navbar_path, $footer_path, $header_css_scripts, $newfile_profile, $background_image_path, $template_path);

//create bootstrap form 
$rows_per_grid='5';
$grid_class='col-md-4';
$elements_plate='';
$ui_comment='Sql input';
$fileds_n_values_json=magic_sql_json_cols($tbl);
$create_new_file='no';

create_magic_form($newfile_profile,  $fileds_n_values_json, $tbl, $rows_per_grid, $grid_class, $elements_plate, $ui_comment, $write_here, $create_new_file);

//table list 
  
$edit_key='primkey';
$plain_link='no';
$linkcol='';

create_table_ui($newfile_name, $fileds_n_values_json, $tbl, $create_new_file, $edit_key, $plain_link, $linkcol,$write_here);

///============ Create select update insert and delete functions

$primkey='primkey';
$crud_path='../data_control/'.$tbl.'.php';

create_cruds($crud_path, magic_sql_array_cols($tbl), $dbname, $tbl, $primkey);

//== write connection files
$data_includes="
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
//include('./data_control/datafeed.php');
include('./data_control/".$tbl.".php');
//include('./adminsessionmonitor.php')";

$remove_primkey='`primkey`=\'$primkey\',';
$remove_null_node1='<input class="form-control" id="txt_primkey" name="txt_primkey" value="<?php echo $app_nodes_node["primkey"];?>" placeholder="NULL" type="text">';
//========= replace text in a file_path
$item_to_be_replaced='ob_start()';
$item_to_replace_with=$data_includes;

bend_replace_file_section($newfile_profile, $item_to_be_replaced, $item_to_replace_with);
bend_replace_file_section($newfile_name, $item_to_be_replaced, $item_to_replace_with);
bend_replace_file_section($crud_path, $remove_primkey, "");
bend_replace_file_section($newfile_profile, $remove_null_node, "");


